"""AOGConnector companion bridge: FS25 named pipe -> AgOpenGPS (AgIO) UDP.

Reads vehicle telemetry from FS25 over the \\\\.\\pipe\\AOGConnector_pipe named pipe,
converts the world position into a synthetic lat/lon, and sends an AOG-compatible
"$PANDA" NMEA sentence via UDP to AgIO. AgIO steer commands return to FS25 through
the marked process-memory buffer, so the bridge -> game direction requires no file.

Requires: pip install pywin32

Known open assumptions (need empirical verification against real AOG):
  - Axis mapping: FS25 +Z -> north (latitude), FS25 +X -> east (longitude).
  - Origin lat/lon is arbitrary (no real-world georeference) - configurable below.
  - imuHeading/imuRoll/imuPitch fields are sent as degrees*10 (integer), matching
    HelpfulMods/AOGFirmware/GPS.ino's RAD_TO_DEG_X_10 scaling.
"""
import math
import msvcrt
import os
import socket
import struct
import threading
import time
import traceback

import pywintypes
import win32event
import win32file
import win32pipe

from process_memory import ProcessMemoryBuffer, build_steer_command, build_machine_command

PIPE_NAME = r"\\.\pipe\AOGConnector_pipe"
# Real AOG firmware never hardcodes AgIO's IP - it broadcasts on the LAN subnet (see
# ipDestination in HelpfulMods/AOGFirmware/AW_CANBUS.ino) so AgIO can run on any device.
# Default to the same behavior so AgIO can run on a separate PC/tablet; override with
# AOG_AGIO_HOST if broadcast is blocked (e.g. Wi-Fi AP client isolation) and you want to
# target AgIO's machine directly.
AGIO_HOST = os.environ.get("AOG_AGIO_HOST", "255.255.255.255")
AGIO_PORT = 9999          # port AgIO listens on for module -> AgIO traffic
STEER_MODULE_PORT = 8888  # port the steer module listens on for AgIO -> module traffic

# How often we actually forward a $PANDA sentence to AgIO, independent of how fast
# FS25 writes to the pipe - tune this without touching AOGTelemetry.lua/relaunching FS25.
# Bounded above by AOGTelemetry.PIPE_SEND_RATE_HZ (40Hz) in AOGTelemetry.lua.
AGIO_SEND_RATE_HZ = 20
AGIO_SEND_INTERVAL_SEC = 1.0 / AGIO_SEND_RATE_HZ

# Mirrors HelpfulMods/AOGFirmware/AW_CANBUS.ino's fixed byte arrays
HELLO_AGIO = bytes([0x80, 0x81, 0x7F, 0xC7, 1, 0, 0x47])
# helloSteerPosition (bytes 7/8) is always 0 in the reference firmware too - dead field
HELLO_FROM_AUTOSTEER = bytes([0x80, 0x81, 0x7E, 0x7E, 0x05, 0x00, 0x00, 0x00, 0x00, 0x00, 0x47])
HELLO_FROM_IMU = bytes([0x80, 0x81, 0x79, 0x79, 0x05, 0x00, 0x00, 0x00, 0x00, 0x00, 0x47])
PGN_STEER_DATA = 0xFE   # 254, AgIO -> module steer command
PGN_STEER_REPLY = 0xFD  # 253, module -> AgIO "From AutoSteer"
PGN_HELLO_FROM_AGIO = 200  # 0xC8, AgIO's module-scan request
PGN_MACHINE_DATA = 0xEF   # 239, AgIO -> machine module; byte 7 is hydLift

# shared with the steer-module thread; plain assignment is atomic enough here
latest_steer_angle_deg = 0.0
latest_heading_deg = 0.0
latest_roll_deg = 0.0
latest_pitch_deg = 0.0
latest_operator_override = 0
last_fd_reply_info = None
last_logged_steer_status = None
last_logged_machine_uturn = None

# Publish a single immutable snapshot across threads: sequence, setpoint, status,
# receive time. Only actual UDP commands advance the sequence, so replaying a stale
# snapshot cannot refresh FS25's watchdog or masquerade as an off acknowledgement.
latest_steer_command = None
latest_machine_command = None  # independent sequence, hydLift, receive time
STEER_COMMAND_INTERVAL_SEC = 0.1
STEER_COMMAND_TIMEOUT_SEC = 0.5
MACHINE_COMMAND_TIMEOUT_SEC = 0.5
PROCESS_MEMORY_RETRY_SEC = 2.0


def record_steer_command(data):
    global latest_steer_command
    previous = latest_steer_command
    sequence = 0 if previous is None else (previous[0] + 1) % 1_000_000_000
    latest_steer_command = (
        sequence, struct.unpack("<h", data[8:10])[0] * 0.01, data[7], time.monotonic())


def current_steer_frame():
    command = latest_steer_command
    if command is None or time.monotonic() - command[3] >= STEER_COMMAND_TIMEOUT_SEC:
        return None
    return build_steer_command(*command[:3])


def record_machine_command(data):
    global latest_machine_command
    # PGN.md: 8 payload bytes plus header and checksum, zero-based byte 7.
    if (len(data) != 14 or data[:5] != bytes([0x80, 0x81, 0x7F, PGN_MACHINE_DATA, 8]) or
            (sum(data[2:13]) & 0xFF) != data[13] or data[7] not in (0, 1, 2)):
        return
    previous = latest_machine_command
    sequence = 0 if previous is None else (previous[0] + 1) % 1_000_000_000
    latest_machine_command = (sequence, data[7], time.monotonic())


def current_command_frame():
    # Both records share one committed write but have independent freshness and
    # sequences. Machine traffic must never keep an old steering command alive.
    frames = []
    steer_frame = current_steer_frame()
    if steer_frame is not None:
        frames.append(steer_frame)
    machine = latest_machine_command
    if machine is not None and time.monotonic() - machine[2] < MACHINE_COMMAND_TIMEOUT_SEC:
        frames.append(build_machine_command(*machine[:2]))
    return "\n".join(frames) if frames else None

# Set by _keypress_watcher; checked between short I/O waits so pressing 'q' exits
# promptly, even while the pipe would otherwise block indefinitely waiting for FS25.
_shutdown_requested = False
IO_POLL_TIMEOUT_MS = 200

def _keypress_watcher():
    # Only 'q' quits - not "any key" - so an incidental keystroke in this terminal
    # (alt-tab, a stray click-then-key, etc.) during a long FS25 session can't silently
    # kill the bridge and stop command delivery for the rest of the session.
    global _shutdown_requested
    while not _shutdown_requested:
        key = msvcrt.getch()
        if key in (b"q", b"Q"):
            _shutdown_requested = True

def _wait_overlapped(pipe, overlapped):
    """Waits on an overlapped op in short slices, polling _shutdown_requested between
    them. Returns True if the op completed, False if we bailed out for shutdown."""
    while True:
        rc = win32event.WaitForSingleObject(overlapped.hEvent, IO_POLL_TIMEOUT_MS)
        if rc == win32event.WAIT_OBJECT_0:
            return True
        if _shutdown_requested:
            win32file.CancelIo(pipe)
            try:
                win32file.GetOverlappedResult(pipe, overlapped, True)
            except pywintypes.error:
                pass
            return False

# Arbitrary local-plane origin - AOG just needs a self-consistent field, not real-world coords.
ORIGIN_LAT = 45.0
ORIGIN_LON = -93.0
METERS_PER_DEG_LAT = 111320.0

def world_to_latlon(world_x, world_z):
    lat = ORIGIN_LAT + (world_z / METERS_PER_DEG_LAT)
    meters_per_deg_lon = METERS_PER_DEG_LAT * math.cos(math.radians(ORIGIN_LAT))
    lon = ORIGIN_LON + (-world_x / meters_per_deg_lon)
    return lat, lon

def to_nmea_lat(lat):
    hemi = "N" if lat >= 0 else "S"
    lat = abs(lat)
    deg = int(lat)
    minutes = (lat - deg) * 60
    return f"{deg:02d}{minutes:08.5f}", hemi

def to_nmea_lon(lon):
    hemi = "E" if lon >= 0 else "W"
    lon = abs(lon)
    deg = int(lon)
    minutes = (lon - deg) * 60
    return f"{deg:03d}{minutes:08.5f}", hemi

def nmea_checksum(body):
    checksum = 0
    for ch in body:
        checksum ^= ord(ch)
    return f"{checksum:02X}"

def build_panda_sentence(world_x, world_z, speed_kmh, heading_deg, yaw_rate_deg_per_sec, roll_deg, pitch_deg):
    lat, lon = world_to_latlon(world_x, world_z)
    lat_str, lat_ns = to_nmea_lat(lat)
    lon_str, lon_ew = to_nmea_lon(lon)
    fix_time = time.strftime("%H%M%S", time.gmtime()) + ".00"
    fix_quality = "4"
    num_sats = "12"
    hdop = "1.0"
    altitude = "0.0"
    age_dgps = "0"
    speed_knots = f"{speed_kmh * 0.539957:.2f}"
    imu_heading = f"{heading_deg * 10:.0f}"
    imu_roll = f"{roll_deg * 10:.0f}"
    imu_pitch = f"{pitch_deg * 10:.0f}"
    imu_yaw_rate = f"{yaw_rate_deg_per_sec:.1f}"
    fields = [fix_time, lat_str, lat_ns, lon_str, lon_ew, fix_quality, num_sats, hdop,
              altitude, age_dgps, speed_knots, imu_heading, imu_roll, imu_pitch, imu_yaw_rate]
    body = "PANDA," + ",".join(fields)
    return f"${body}*{nmea_checksum(body)}\r\n"

def steer_switch_is_off():
    # Bit 1 is the steering switch OFF state, not a momentary override pulse.
    # Keep it off after AOG acknowledges disengagement: clearing it at that point
    # creates an off -> on switch edge that AOG can interpret as re-engagement.
    # A new AOG guidance-on request may release it, unless the operator overrides.
    command = latest_steer_command
    return (latest_operator_override == 1 or command is None or
            time.monotonic() - command[3] >= STEER_COMMAND_TIMEOUT_SEC or
            (command[2] & 1) == 0)


def build_fd_reply(steer_angle_deg, heading_deg, roll_deg, steer_switch_off):
    # Mirrors the AOG[] template/field layout in HelpfulMods/AOGFirmware/AW_CANBUS.ino
    packet = bytearray([0x80, 0x81, 0x7F, 0xFD, 8, 0, 0, 0, 0, 0, 0, 0, 0, 0xCC])
    sa = int(round(steer_angle_deg * 100)) & 0xFFFF
    packet[5] = sa & 0xFF
    packet[6] = (sa >> 8) & 0xFF
    heading = int(round(heading_deg)) & 0xFFFF
    packet[7] = heading & 0xFF
    packet[8] = (heading >> 8) & 0xFF
    roll = int(round(roll_deg)) & 0xFFFF
    packet[9] = roll & 0xFF
    packet[10] = (roll >> 8) & 0xFF
    if steer_switch_off:
        packet[11] = 2
    else:
        packet[11] = 0
    packet[12] = 0  # pwmDisplay - no real autosteer motor
    packet[13] = sum(packet[2:13]) & 0xFF
    return bytes(packet)

def build_PGN250_reply(engaged):
    PGN_250 = bytearray([0x80,0x81, 0x7E, 0xFB, 8, 0, 0, 0, 0, 0,0,0,0, 0xCC])
    if engaged:
        PGN_250[5] = 0
    else:
        PGN_250[5] = 0xbb
    return bytes(PGN_250)


def steer_module_loop():
    """Background thread: periodic helloAgIO heartbeat, PGN 0xFD reply on steer data,
    and helloFromAutoSteer/helloFromIMU replies to AgIO's module-scan (PGN 200) so AgIO
    lists both an autosteer module and an IMU module, not just the GPS."""
    global last_fd_reply_info, last_logged_steer_status, last_logged_machine_uturn
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    sock.bind(("0.0.0.0", STEER_MODULE_PORT))
    sock.settimeout(1.0)
    while True:
        try:
            data, addr = sock.recvfrom(1024)
            if len(data) > 9 and data[0] == 0x80 and data[1] == 0x81 and data[3] == PGN_STEER_DATA:
                status = data[7]
                if status != last_logged_steer_status:
                    previous_status = ("unknown" if last_logged_steer_status is None
                                       else f"0x{last_logged_steer_status:02X}")
                    frame_valid = (len(data) == 14 and data[2] == 0x7F and data[4] == 8 and
                                   (sum(data[2:13]) & 0xFF) == data[13])
                    steer_angle_deg = struct.unpack("<h", data[8:10])[0] * 0.01
                    print(
                        f"[AOGBridge] AOG steer status changed {previous_status}->0x{status:02X} "
                        f"(bits={status:08b}, bit0={status & 1}, "
                        f"steerAngle={steer_angle_deg:.2f} deg, frame={'valid' if frame_valid else 'invalid'}, "
                        f"from={addr[0]}:{addr[1]}, len={len(data)}, raw={data.hex(' ')})"
                    )
                    last_logged_steer_status = status
                record_steer_command(data)
                reply = build_fd_reply(latest_steer_angle_deg, latest_heading_deg,
                                       latest_roll_deg, steer_switch_is_off())
                reply_address = (addr[0], AGIO_PORT)
                bytes_sent = sock.sendto(reply, reply_address)
                last_fd_reply_info = (
                    f"steerAngle={latest_steer_angle_deg:.2f} heading={latest_heading_deg:.1f} "
                    f"roll={latest_roll_deg:.1f} switch={reply[11]} sent={bytes_sent}/{len(reply)} "
                    f"to={reply_address[0]}:{reply_address[1]} packet={reply.hex(' ')}"
                )
                # AgIO prefers module status broadcast rather than unicast to the sender.
                # sock.sendto(bytes(reply250), (AGIO_HOST, AGIO_PORT))
            elif len(data) > 3 and data[3] == PGN_MACHINE_DATA:
                if len(data) > 5 and data[0] == 0x80 and data[1] == 0x81:
                    uturn = data[5]
                    if uturn != last_logged_machine_uturn:
                        frame_valid = (len(data) == 14 and data[2] == 0x7F and data[4] == 8 and
                                       (sum(data[2:13]) & 0xFF) == data[13])
                        hyd_lift = data[7] if len(data) > 7 else None
                        print(
                            f"[AOGBridge] AOG Machine Data uturn changed "
                            f"{last_logged_machine_uturn!r}->{uturn} "
                            f"(hydLift={hyd_lift}, frame={'valid' if frame_valid else 'invalid'}, "
                            f"from={addr[0]}:{addr[1]}, len={len(data)}, raw={data.hex(' ')})"
                        )
                        last_logged_machine_uturn = uturn
                record_machine_command(data)
            elif len(data) > 4 and data[0] == 0x80 and data[1] == 0x81 and data[3] == PGN_HELLO_FROM_AGIO:
                sa = int(round(latest_steer_angle_deg * 100)) & 0xFFFF
                autosteer_reply = bytearray(HELLO_FROM_AUTOSTEER)
                autosteer_reply[5] = sa & 0xFF
                autosteer_reply[6] = (sa >> 8) & 0xFF
                autosteer_reply[9] = 2 if steer_switch_is_off() else 0
                autosteer_reply[-1] = sum(autosteer_reply[2:-1]) & 0xFF
                reply_address = (addr[0], AGIO_PORT)
                sock.sendto(bytes(autosteer_reply), reply_address)
                sock.sendto(HELLO_FROM_IMU, reply_address)
        except socket.timeout:
            pass
        except ConnectionResetError:
            pass


def steer_command_memory_loop():
    """Relay fresh steering and machine commands with independent sequences."""
    while not _shutdown_requested:
        try:
            with ProcessMemoryBuffer() as buffer:
                print(f"Connected to FS25 command buffer at 0x{buffer.address:X}.")
                while not _shutdown_requested:
                    frame = current_command_frame()
                    if frame is not None:
                        buffer.write_committed(frame)
                    time.sleep(STEER_COMMAND_INTERVAL_SEC)
        except (OSError, RuntimeError) as err:
            if not _shutdown_requested:
                print(f"FS25 command buffer unavailable ({err}); retrying...")
                time.sleep(PROCESS_MEMORY_RETRY_SEC)

def main():
    global latest_steer_angle_deg, latest_heading_deg, latest_roll_deg, latest_pitch_deg
    global latest_operator_override
    threading.Thread(target=steer_module_loop, daemon=True).start()
    threading.Thread(target=steer_command_memory_loop, daemon=True).start()
    threading.Thread(target=_keypress_watcher, daemon=True).start()
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    try:
        while not _shutdown_requested:
            pipe = win32pipe.CreateNamedPipe(
                PIPE_NAME, win32pipe.PIPE_ACCESS_INBOUND | win32file.FILE_FLAG_OVERLAPPED,
                win32pipe.PIPE_TYPE_MESSAGE | win32pipe.PIPE_READMODE_MESSAGE | win32pipe.PIPE_WAIT,
                1, 65536, 65536, 0, None)
            print(f"Waiting for FS25 to connect on {PIPE_NAME} ... (press 'q' to quit)")
            overlapped = pywintypes.OVERLAPPED()
            overlapped.hEvent = win32event.CreateEvent(None, True, False, None)
            try:
                win32pipe.ConnectNamedPipe(pipe, overlapped)
                if not _wait_overlapped(pipe, overlapped):
                    win32file.CloseHandle(pipe)
                    break
            except pywintypes.error as err:
                if err.winerror != 535:
                    win32file.CloseHandle(pipe)
                    continue
            print(f"Connected. Forwarding to AgIO at {AGIO_HOST}:{AGIO_PORT} (press 'q' to quit)...")
            buffer = ""
            last_agio_send = 0.0
            try:
                while not _shutdown_requested:
                    read_overlapped = pywintypes.OVERLAPPED()
                    read_overlapped.hEvent = win32event.CreateEvent(None, True, False, None)
                    _, read_buf = win32file.ReadFile(pipe, 4096, read_overlapped)
                    if not _wait_overlapped(pipe, read_overlapped):
                        break
                    nbytes = win32file.GetOverlappedResult(pipe, read_overlapped, False)
                    buffer += bytes(read_buf[:nbytes]).decode("utf-8", errors="replace")
                    while "\n" in buffer:
                        line, buffer = buffer.split("\n", 1)
                        line = line.strip()
                        if not line:
                            continue
                        values = line.split(",")
                        world_x, world_z, speed_kmh, heading_deg, steer_angle_deg, yaw_rate_deg_per_sec, roll_deg, pitch_deg = (float(v) for v in values[:8])
                        if len(values) >= 9:
                            latest_operator_override = int(values[8])
                        else:
                            latest_operator_override = 0
                        latest_steer_angle_deg = steer_angle_deg
                        latest_heading_deg = heading_deg
                        latest_roll_deg = roll_deg
                        latest_pitch_deg = pitch_deg
                        now = time.monotonic()
                        if now - last_agio_send < AGIO_SEND_INTERVAL_SEC:
                            continue
                        last_agio_send = now
                        sentence = build_panda_sentence(world_x, world_z, speed_kmh, heading_deg, yaw_rate_deg_per_sec, roll_deg, pitch_deg)
                        try:
                            sock.sendto(sentence.encode("ascii"), (AGIO_HOST, AGIO_PORT))
                        except ConnectionResetError:
                            pass
                        extra = f" | FD: {last_fd_reply_info}" if last_fd_reply_info else " | FD: (none yet)"
                        # print(sentence.strip() + extra)
            except pywintypes.error as err:
                if not _shutdown_requested:
                    print(f"FS25 disconnected ({err.strerror}), waiting for reconnect...")
            finally:
                win32file.CloseHandle(pipe)
    except KeyboardInterrupt:
        pass
    finally:
        sock.close()
        print("Stopped.")

if __name__ == "__main__":
    main()
