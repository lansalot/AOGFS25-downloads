# AOG Connector v0.1.0.0 for Farming Simulator 25

## Quick Start

1. **Install the Mod:** Copy `FS25_AOGConnector.zip` to your FS25 mods folder:
   `C:\Users\{your-user}\Documents\My Games\FarmingSimulator2025\mods`
   
   **DO NOT extract** this inner ZIP file - keep it as-is.

2. **Set up the Bridge:** Run `Setup.cmd` to install Python dependencies.
   This creates a local `.venv` environment.

3. **Start the Bridge:** Run `Start-Bridge.cmd` when playing FS25.
   Keep its window open while playing.

4. **AgOpenGPS:** Install AgOpenGPS separately and configure UDP connections.

See `INSTALL.txt` for detailed instructions, troubleshooting, and networking setup.

## Requirements
- Windows 64-bit with FS25 installed
- Python 3.12 x64 (with launcher `py`)
- AgOpenGPS/AgIO (separate installation)
- FS25 save game with mod enabled

## Verification
Compare SHA-256 checksums after download:
```powershell
Get-FileHash .\AOGConnector-0.1.0.0.zip -Algorithm SHA256
```
Checksum listed in `SHA256SUMS.txt` alongside the ZIP on the download page.

---
Built by 0.1.0.0
