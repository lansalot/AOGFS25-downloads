@echo off
setlocal
cd /d "%~dp0"
rem Double-clickable entry point for the AOG Connector launcher.
rem -STA is required by WinForms; -Bypass avoids execution-policy prompts.
powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0AOGConnector.ps1" %*
set "launcher_exit=%errorlevel%"
if not defined AOG_NONINTERACTIVE if %launcher_exit% neq 0 (
    echo.
    echo Launcher exited with code %launcher_exit%. See the window above and INSTALL.txt.
    pause
)
exit /b %launcher_exit%
