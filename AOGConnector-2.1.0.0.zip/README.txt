# AOG Connector v2.1.0.0 for Farming Simulator 25

## Quick Start

1. **Install the Mod:** Copy `FS25_AOGConnector.zip` to your FS25 mods folder:
   `C:\Users\{your-user}\Documents\My Games\FarmingSimulator2025\mods`
   
   **DO NOT extract** this inner ZIP file - keep it as-is.

2. **Run the Launcher:** Double-click `Start-AOGConnector.cmd`. It opens a window
   that checks Python and the bridge dependencies (offering to install Python if
   it is missing), creates a local `.venv`, and starts the bridge when ready.

3. **AgOpenGPS:** Install AgOpenGPS separately and configure UDP connections.

See `INSTALL.txt` for detailed instructions, troubleshooting, and networking setup.

## Requirements
- Windows 64-bit with FS25 installed
- Python 3.12 x64 (the launcher can install it for you, or open python.org)
- AgOpenGPS/AgIO (separate installation)
- FS25 save game with mod enabled

## Verification
Compare SHA-256 checksums after download:
```powershell
Get-FileHash .\AOGConnector-2.1.0.0.zip -Algorithm SHA256
```
Checksum listed in `SHA256SUMS.txt` alongside the ZIP on the download page.

---
Built by 2.1.0.0
