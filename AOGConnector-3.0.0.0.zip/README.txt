# AOG Connector v3.0.0.0 for Farming Simulator 25

## Quick Start

1. **Install the Mod:** Run `Start-AOGConnector.cmd` and click **Install FS25
   mod** in the Dependencies section, or copy `FS25_AOGConnector.zip` manually
   to your FS25 mods folder:
   `C:\Users\{your-user}\Documents\My Games\FarmingSimulator2025\mods`

   **DO NOT extract** this inner ZIP file - keep it as-is. The launcher asks
   before replacing an existing copy.

2. **Run the Launcher:** Double-click `Start-AOGConnector.cmd`. It opens a window
   that checks Python and the bridge dependencies (offering to install Python if
   it is missing), creates a local `.venv`, and starts the bridge when ready.

3. **AgOpenGPS (optional):** Use the launcher to download the latest compiled
   AgOpenGPS release into the launcher's `AgOpenGPSApp` subfolder and start it.
   The launcher also adds the bundled starter profiles to `Documents\AgOpenGPS`
   without replacing files that are already there.

4. **AgOpenGPS Web (optional):** Download the compiled Windows nightly and
   start it in desktop or headless mode from the launcher. No .NET SDK is needed.

See `INSTALL.txt` for detailed instructions, troubleshooting, and networking setup.

## Requirements
- Windows 64-bit with FS25 installed
- Python 3.12 x64 (the launcher can install it for you, or open python.org)
- AgOpenGPS/AgIO (optional; the launcher can install the compiled release)
- AgOpenGPS Web (optional; the launcher downloads the compiled nightly)
- FS25 save game with mod enabled

## Verification
Compare SHA-256 checksums after download:
```powershell
Get-FileHash .\AOGConnector-3.0.0.0.zip -Algorithm SHA256
```
Checksum listed in `SHA256SUMS.txt` alongside the ZIP on the download page.

---
Built by 3.0.0.0
