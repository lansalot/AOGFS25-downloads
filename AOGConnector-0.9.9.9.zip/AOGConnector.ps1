<#
.SYNOPSIS
    AOG Connector launcher: GUI dependency checker plus bridge starter.

.DESCRIPTION
    Single entry point for the AOG Connector release. Replaces the previous
    Setup.cmd / Start-Bridge.cmd pair with one double-clickable file.

    Checks performed:
      1. 64-bit Python 3.9 or newer is available (launcher, PATH or registry).
      2. The companion\ release files are present.
      3. A local .venv exists.
      4. The bridge requirements (pywin32) import from that .venv.

    When Python is missing you can either let the launcher download and install
    the official python.org installer silently for the current user (no admin
    rights needed) or open the python.org download page and install it yourself.

    Once every check passes, "Start Bridge" launches companion\aog_bridge.py in
    its own console window. That window is where the bridge logs live and where
    pressing 'q' stops it, so keep it open while playing.

    Nothing outside this folder is modified: the virtual environment lives in
    .\.venv and system-wide Python packages are never touched.

.PARAMETER SetupOnly
    Verify/install dependencies and exit without starting the bridge.

.PARAMETER NonInteractive
    Run the same checks in the console with no GUI. Also enabled by the
    AOG_NONINTERACTIVE environment variable, matching the old scripts.

.EXAMPLE
    .\AOGConnector.ps1
    Opens the launcher window.

.EXAMPLE
    .\AOGConnector.ps1 -NonInteractive -SetupOnly
    Verifies dependencies from a script or CI job, then exits.

.NOTES
    Non-interactive exit codes:
    0 ready   1 setup failed   2 Python missing   3 release files missing
#>
[CmdletBinding()]
param(
    [switch]$SetupOnly,
    [switch]$NonInteractive
)

$ErrorActionPreference = 'Stop'

# ---------------------------------------------------------------------------
# Paths. Everything is relative to this script so the release folder can live
# anywhere, including on a path that contains spaces.
#
# $PSScriptRoot can be empty depending on how the script is invoked, and silently
# falling back to the current directory would then point .venv and companion\ at
# the wrong place. So the fallback is validated against the expected layout.
# ---------------------------------------------------------------------------
$script:Root = $PSScriptRoot
if (-not $script:Root) { $script:Root = Split-Path -Parent $MyInvocation.MyCommand.Path }
if (-not $script:Root) { $script:Root = (Get-Location).Path }
$script:Root = (Resolve-Path -LiteralPath $script:Root).Path

$script:VenvDir      = Join-Path $script:Root '.venv'
$script:VenvPython   = Join-Path $script:VenvDir 'Scripts\python.exe'
$script:CompanionDir = Join-Path $script:Root 'companion'
$script:Requirements = Join-Path $script:CompanionDir 'requirements.txt'
$script:BridgeScript = Join-Path $script:CompanionDir 'aog_bridge.py'
$script:WorkDir      = Join-Path ([System.IO.Path]::GetTempPath()) ("aog-launcher-" + [Guid]::NewGuid().ToString('N'))

$script:PythonIndexUrl   = 'https://www.python.org/ftp/python/'
$script:PythonWindowsUrl = 'https://www.python.org/downloads/windows/'
$script:PreferredPython  = '3.12'
$script:MinPythonVersion = [Version]'3.9'

# Child processes must not inherit a legacy console code page, otherwise the
# bridge's non-ASCII output is mangled while it is being tailed.
$env:PYTHONIOENCODING = 'utf-8'
$env:PYTHONUNBUFFERED = '1'

# ---------------------------------------------------------------------------
# Small process helpers
# ---------------------------------------------------------------------------

function ConvertTo-QuotedArgument {
    param([Parameter(Mandatory = $true)][string]$Value)
    if ($Value -match '[\s"]') {
        return '"' + ($Value -replace '"', '\"') + '"'
    }
    return $Value
}

function Invoke-Captured {
    <#
        Runs a short-lived command and captures its output. Only used for the
        quick version/bitness probes, which are fast enough to run inline.
    #>
    param(
        [Parameter(Mandatory = $true)][string]$FilePath,
        [string[]]$Arguments = @(),
        [string]$WorkingDirectory = $script:Root
    )

    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $FilePath
    $psi.Arguments = (($Arguments | ForEach-Object { ConvertTo-QuotedArgument $_ }) -join ' ')
    $psi.WorkingDirectory = $WorkingDirectory
    $psi.UseShellExecute = $false
    $psi.CreateNoWindow = $true
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true

    $process = New-Object System.Diagnostics.Process
    $process.StartInfo = $psi
    try {
        $null = $process.Start()
    }
    catch {
        return [pscustomobject]@{ ExitCode = -1; Output = ''; Error = $_.Exception.Message }
    }

    $stdout = $process.StandardOutput.ReadToEnd()
    $stderr = $process.StandardError.ReadToEnd()
    $process.WaitForExit()

    return [pscustomobject]@{
        ExitCode = $process.ExitCode
        Output   = $stdout
        Error    = $stderr
    }
}

# ---------------------------------------------------------------------------
# Python discovery
# ---------------------------------------------------------------------------

function Get-RegisteredPythonExecutables {
    <#
        Finds python.exe from the per-user and per-machine PythonCore registry
        keys. This is what makes a freshly installed Python visible to the
        launcher when PATH has not been refreshed in this process yet.
    #>
    $executables = New-Object System.Collections.Generic.List[string]
    $entries = @()

    foreach ($root in @('HKCU:\Software\Python\PythonCore', 'HKLM:\SOFTWARE\Python\PythonCore')) {
        if (-not (Test-Path -LiteralPath $root)) { continue }
        foreach ($versionKey in @(Get-ChildItem -LiteralPath $root -ErrorAction SilentlyContinue)) {
            if ($versionKey.PSChildName -notmatch '^\d+(\.\d+)+$') { continue }

            $install = Get-ItemProperty -LiteralPath (Join-Path $versionKey.PSPath 'InstallPath') -ErrorAction SilentlyContinue
            if (-not $install) { continue }

            $exe = $install.ExecutablePath
            if ([string]::IsNullOrWhiteSpace($exe)) { $exe = $install.'(default)' }
            if ([string]::IsNullOrWhiteSpace($exe)) { continue }

            $entries += [pscustomobject]@{ Version = $versionKey.PSChildName; Path = $exe }
        }
    }

    foreach ($entry in ($entries | Sort-Object { [version]$_.Version } -Descending)) {
        if ($executables -notcontains $entry.Path) { $executables.Add($entry.Path) }
    }
    return $executables.ToArray()
}

function Get-PythonCandidates {
    $candidates = New-Object System.Collections.Generic.List[object]

    $launcher = Get-Command 'py.exe' -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1
    if (-not $launcher) { $launcher = Get-Command 'py' -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1 }
    if ($launcher) {
        # Prefer the tested baseline, then fall back to the newest 3.x present.
        $candidates.Add([pscustomobject]@{
            FilePath  = $launcher.Source
            Arguments = @("-$script:PreferredPython")
            Label     = "py -$script:PreferredPython"
        })
        $candidates.Add([pscustomobject]@{ FilePath = $launcher.Source; Arguments = @('-3'); Label = 'py -3' })
    }

    foreach ($name in @('python.exe', 'python3.exe', 'python', 'python3')) {
        $command = Get-Command $name -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($command) {
            $candidates.Add([pscustomobject]@{
                FilePath  = $command.Source
                Arguments = @()
                Label     = "$name on PATH"
            })
        }
    }

    foreach ($exe in @(Get-RegisteredPythonExecutables)) {
        $candidates.Add([pscustomobject]@{ FilePath = $exe; Arguments = @(); Label = 'registered Python install' })
    }

    return $candidates.ToArray()
}

function Get-PythonInfo {
    <#
        Probes each candidate and returns the first usable 64-bit Python that is
        new enough, or $null when none was found.
    #>
    $probe = 'import struct, sys; print("%d.%d.%d|%d" % (sys.version_info[0], sys.version_info[1], sys.version_info[2], struct.calcsize("P")))'

    foreach ($candidate in @(Get-PythonCandidates)) {
        $arguments = @($candidate.Arguments) + @('-c', $probe)
        $result = Invoke-Captured -FilePath $candidate.FilePath -Arguments $arguments
        if ($result.ExitCode -ne 0) { continue }

        $line = ($result.Output -split "`r?`n" | Where-Object { $_.Trim() } | Select-Object -First 1)
        if ("$line" -notmatch '^(\d+)\.(\d+)\.(\d+)\|(\d+)$') { continue }

        $version = [Version]"$($Matches[1]).$($Matches[2]).$($Matches[3])"
        if ($version -lt $script:MinPythonVersion) { continue }
        if ($Matches[4] -ne '8') { continue }

        return [pscustomobject]@{
            FilePath   = $candidate.FilePath
            Arguments  = @($candidate.Arguments)
            Version    = $version
            Is64Bit    = $true
            Label      = $candidate.Label
            Executable = ($candidate.FilePath + ' ' + (@($candidate.Arguments) -join ' ')).Trim()
        }
    }
    return $null
}

# ---------------------------------------------------------------------------
# Dependency checks and setup
# ---------------------------------------------------------------------------

function Get-MissingReleaseFiles {
    $missing = @()
    if (-not (Test-Path -LiteralPath $script:BridgeScript)) { $missing += 'companion\aog_bridge.py' }
    if (-not (Test-Path -LiteralPath $script:Requirements)) { $missing += 'companion\requirements.txt' }
    return $missing
}

function Test-BridgeDependencies {
    <#
        True when the .venv interpreter exists and can import every win32 module
        the bridge needs. Missing pywin32 is the usual reason this is false.
    #>
    if (-not (Test-Path -LiteralPath $script:VenvPython)) { return $false }
    $result = Invoke-Captured -FilePath $script:VenvPython -Arguments @('-c', 'import win32pipe, win32file, win32event, pywintypes')
    return ($result.ExitCode -eq 0)
}

function Test-VenvPipHealthy {
    <#
        A half-created or corrupted .venv can exist while its pip is unusable
        ("No module named 'pip._internal.cli'"). That is not a network problem,
        so it is detected separately and repaired by rebuilding the venv.
    #>
    if (-not (Test-Path -LiteralPath $script:VenvPython)) { return $false }
    $result = Invoke-Captured -FilePath $script:VenvPython -Arguments @('-m', 'pip', '--version')
    return ($result.ExitCode -eq 0)
}

function Remove-Venv {
    if (Test-Path -LiteralPath $script:VenvDir) {
        Remove-Item -LiteralPath $script:VenvDir -Recurse -Force -ErrorAction SilentlyContinue
    }
}

function Invoke-VenvCreation {
    param([Parameter(Mandatory = $true)]$Python)
    return Invoke-Captured -FilePath $Python.FilePath -Arguments (@($Python.Arguments) + @('-m', 'venv', $script:VenvDir))
}

function Invoke-PipInstall {
    <#
        Installs companion\requirements.txt into the local .venv only. This never
        touches system-wide packages. A venv whose pip is unusable is rebuilt once
        before giving up.
    #>
    param($Python)

    if (-not (Test-Path -LiteralPath $script:VenvPython)) {
        return [pscustomobject]@{ ExitCode = -1; Output = ''; Error = 'Virtual environment is missing.' }
    }

    $result = Invoke-Captured -FilePath $script:VenvPython -Arguments @('-m', 'pip', 'install', '--disable-pip-version-check', '-r', $script:Requirements)
    if ($result.ExitCode -ne 0) {
        if ($result.Error -match 'Could not open requirements file') {
            # The release layout is broken (usually a partially extracted ZIP or a
            # launcher copied out of it), so say so instead of blaming the network.
            return [pscustomobject]@{
                ExitCode = -1
                Output   = $result.Output
                Error    = "Requirements file not found at $script:Requirements`r`nExtract the complete release ZIP again so that companion\requirements.txt sits next to the launcher."
            }
        }
        return $result
    }

    # A venv that cannot import pip/_internal/cli is corrupt rather than offline,
    # so rebuild it and retry once. Real network/build failures return non-zero
    # above and fall through to the error report instead.
    if (-not (Test-VenvPipHealthy)) {
        if (-not $Python) { return $result }
        Remove-Venv
        $rebuilt = Invoke-VenvCreation -Python $Python
        if ($rebuilt.ExitCode -ne 0 -or -not (Test-Path -LiteralPath $script:VenvPython)) { return $rebuilt }
        return Invoke-Captured -FilePath $script:VenvPython -Arguments @('-m', 'pip', 'install', '--disable-pip-version-check', '-r', $script:Requirements)
    }
    return $result
}

function Get-LatestPythonInstallerUrl {
    <#
        Resolves the newest 64-bit CPython installer for the preferred series by
        scanning the official python.org FTP index over HTTPS. Returns $null when
        the index cannot be read, so the caller can fall back to the web page.
    #>
    try {
        $response = Invoke-WebRequest -Uri $script:PythonIndexUrl -UseBasicParsing -TimeoutSec 30
    }
    catch {
        Write-Verbose "python.org index unavailable: $($_.Exception.Message)"
        return $null
    }

    $versions = [regex]::Matches($response.Content, '"(3\.\d+\.\d+)/"') |
        ForEach-Object { $_.Groups[1].Value } |
        Sort-Object { [version]$_ } -Descending -Unique

    foreach ($version in $versions) {
        if ($version -notmatch "^$([regex]::Escape($script:PreferredPython))\.") { continue }
        $url = "https://www.python.org/ftp/python/$version/python-$version-amd64.exe"
        try {
            $head = Invoke-WebRequest -Uri $url -Method Head -UseBasicParsing -TimeoutSec 30
            if ($head.StatusCode -eq 200) { return $url }
        }
        catch {
            continue
        }
    }
    return $null
}

function Save-PythonInstaller {
    <#
        Downloads the installer to the temp work folder, reporting progress by
        invoking $Progress. Returns the downloaded file path.
    #>
    param(
        [Parameter(Mandatory = $true)][string]$Url,
        [Parameter(Mandatory = $true)][scriptblock]$Progress
    )

    $destination = Join-Path $script:WorkDir 'python-installer.exe'
    $null = New-Item -ItemType Directory -Path $script:WorkDir -Force

    $client = New-Object System.Net.WebClient
    try {
        $client.Headers.Add('User-Agent', 'AOGConnector-Launcher')

        # WebClient writes the destination file as it downloads, so polling its
        # length is a reliable progress source. An event subscription is not used
        # here because PowerShell cannot convert a scriptblock to the
        # DownloadProgressChangedEventHandler delegate, and event actions run
        # asynchronously so the counter would lag behind anyway.
        $task = $client.DownloadFileTaskAsync([Uri]$Url, $destination)
        while (-not $task.IsCompleted) {
            $partial = 0L
            if (Test-Path -LiteralPath $destination) {
                $partial = (Get-Item -LiteralPath $destination -ErrorAction SilentlyContinue).Length
            }
            & $Progress ('Downloading Python installer... {0:N1} MB' -f ($partial / 1MB)) | Out-Null
            Start-Sleep -Milliseconds 250
        }
        if ($task.IsFaulted) { throw $task.Exception.GetBaseException().Message }
    }
    finally {
        $client.Dispose()
    }

    & $Progress ("Installer downloaded ({0:N1} MB)." -f ((Get-Item -LiteralPath $destination).Length / 1MB)) | Out-Null
    return $destination
}

function Install-PythonSilently {
    <#
        Runs the official installer for the current user only. Quiet mode plus
        PrependPath and the py launcher are what make the follow-up check pass.
        Returns the installer exit code (0 success, 3010 success + reboot).
    #>
    param(
        [Parameter(Mandatory = $true)][string]$InstallerPath,
        [Parameter(Mandatory = $true)][scriptblock]$Progress
    )

    $arguments = @(
        '/quiet',
        'InstallAllUsers=0',
        "PrependPath=1",
        'Include_launcher=1',
        'Include_pip=1',
        'Include_test=0',
        'AssociateFiles=0',
        'Shortcuts=0'
    )

    & $Progress 'Installing Python (this can take a minute)...' | Out-Null
    $result = Invoke-Captured -FilePath $InstallerPath -Arguments $arguments
    if ($result.Error) { & $Progress ("Installer output: " + $result.Error.Trim()) | Out-Null }
    return $result.ExitCode
}

# ---------------------------------------------------------------------------
# Bridge launch
# ---------------------------------------------------------------------------

function Start-Bridge {
    <#
        Starts the bridge in its own console window. The bridge is the thing that
        prints its status and watches for 'q', and msvcrt.getch() only works with
        a real console attached, so it deliberately gets its own window rather
        than being reparented into the GUI. Returns the started process.
    #>
    if (-not (Test-Path -LiteralPath $script:VenvPython)) {
        throw 'Virtual environment is missing.'
    }

    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $script:VenvPython
    $psi.Arguments = '-u ' + (ConvertTo-QuotedArgument $script:BridgeScript)
    $psi.WorkingDirectory = $script:Root
    $psi.UseShellExecute = $false
    $psi.CreateNoWindow = $false

    $process = New-Object System.Diagnostics.Process
    $process.StartInfo = $psi
    $null = $process.Start()
    return $process
}

# ---------------------------------------------------------------------------
# Non-interactive workflow (scripting and CI)
# ---------------------------------------------------------------------------

function Invoke-NonInteractive {
    param([Parameter(Mandatory = $true)][bool]$SetupOnly)

    Write-Host 'AOG Connector dependency check'
    Write-Host "Release folder: $script:Root"
    Write-Host ''

    $missingFiles = Get-MissingReleaseFiles
    if ($missingFiles.Count -gt 0) {
        Write-Host "[FAIL] Release files missing: $($missingFiles -join ', ')"
        Write-Host 'Extract the whole release ZIP again and keep the companion folder together.'
        return 3
    }
    Write-Host '[ OK ] Release files present (companion\aog_bridge.py, companion\requirements.txt)'

    $python = Get-PythonInfo
    if (-not $python) {
        Write-Host "[FAIL] 64-bit Python $($script:MinPythonVersion)+ was not found."
        Write-Host "       Install it from $($script:PythonWindowsUrl) and run this again."
        return 2
    }
    Write-Host "[ OK ] Python $($python.Version) 64-bit ($($python.Label))"
    Write-Host "       $($python.Executable)"

    if (-not (Test-Path -LiteralPath $script:VenvPython)) {
        Write-Host '[....] Creating virtual environment in .venv ...'
        $venv = Invoke-VenvCreation -Python $python
        if ($venv.ExitCode -ne 0 -or -not (Test-Path -LiteralPath $script:VenvPython)) {
            Write-Host "[FAIL] Could not create the virtual environment."
            Write-Host "       $($venv.Error)$($venv.Output)"
            return 1
        }
    }
    Write-Host '[ OK ] Virtual environment ready (.venv)'

    if (-not (Test-BridgeDependencies)) {
        Write-Host '[....] Installing dependencies from companion\requirements.txt ...'
        $pip = Invoke-PipInstall
        if ($pip.ExitCode -ne 0) {
            Write-Host '[FAIL] pip install failed.'
            Write-Host "       $($pip.Error)$($pip.Output)"
            return 1
        }
    }

    if (-not (Test-BridgeDependencies)) {
        Write-Host '[FAIL] pywin32 (win32pipe/win32file/win32event) is still not importable.'
        return 1
    }
    Write-Host '[ OK ] Bridge dependencies satisfied (pywin32 importable)'

    if ($SetupOnly) {
        Write-Host ''
        Write-Host 'Setup complete. Start the bridge whenever you play.'
        return 0
    }

    Write-Host ''
    Write-Host 'All dependencies satisfied. Starting the bridge...'
    $bridge = Start-Bridge
    Write-Host "Bridge running in its own console window (PID $($bridge.Id)). Press 'q' there to stop it."
    return 0
}

# ---------------------------------------------------------------------------
# GUI
# ---------------------------------------------------------------------------

function Initialize-Gui {
    <#
        Builds the launcher window: a checklist of the dependency steps, a log
        pane, and a button row that changes with the current state.
    #>
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing

    $form = New-Object System.Windows.Forms.Form
    $form.Text = 'AOG Connector - Launcher'
    $form.ClientSize = New-Object System.Drawing.Size(760, 620)
    $form.MinimumSize = New-Object System.Drawing.Size(640, 520)
    $form.StartPosition = 'CenterScreen'
    $form.Font = New-Object System.Drawing.Font('Segoe UI', 9)

    $title = New-Object System.Windows.Forms.Label
    $title.Text = 'AOG Connector - Farming Simulator 25 / AgOpenGPS bridge'
    $title.Font = New-Object System.Drawing.Font('Segoe UI', 12, [System.Drawing.FontStyle]::Bold)
    $title.AutoSize = $false
    $title.Location = New-Object System.Drawing.Point(16, 16)
    $title.Size = New-Object System.Drawing.Size(728, 28)
    $form.Controls.Add($title) | Out-Null

    $subtitle = New-Object System.Windows.Forms.Label
    $subtitle.Text = 'Checks Python and the bridge dependencies, then starts the bridge.'
    $subtitle.ForeColor = [System.Drawing.Color]::DimGray
    $subtitle.AutoSize = $false
    $subtitle.Location = New-Object System.Drawing.Point(16, 44)
    $subtitle.Size = New-Object System.Drawing.Size(728, 20)
    $form.Controls.Add($subtitle) | Out-Null

    $checks = New-Object System.Windows.Forms.ListView
    $checks.View = 'Details'
    $checks.FullRowSelect = $true
    $checks.GridLines = $true
    $checks.Location = New-Object System.Drawing.Point(16, 72)
    $checks.Size = New-Object System.Drawing.Size(728, 160)
    $checks.Anchor = 'Top,Left,Right'
    $null = $checks.Columns.Add('Check', 56)
    $null = $checks.Columns.Add('Requirement', 300)
    $null = $checks.Columns.Add('Status', 368)
    $form.Controls.Add($checks) | Out-Null

    $logBox = New-Object System.Windows.Forms.TextBox
    $logBox.Multiline = $true
    $logBox.ReadOnly = $true
    $logBox.ScrollBars = 'Vertical'
    $logBox.WordWrap = $false
    $logBox.Font = New-Object System.Drawing.Font('Consolas', 9)
    $logBox.Location = New-Object System.Drawing.Point(16, 244)
    $logBox.Size = New-Object System.Drawing.Size(728, 300)
    $logBox.Anchor = 'Top,Bottom,Left,Right'
    $form.Controls.Add($logBox) | Out-Null

    $logCaption = New-Object System.Windows.Forms.Label
    $logCaption.Text = 'Log'
    $logCaption.ForeColor = [System.Drawing.Color]::DimGray
    $logCaption.Location = New-Object System.Drawing.Point(16, 226)
    $logCaption.Size = New-Object System.Drawing.Size(400, 16)
    $logCaption.Anchor = 'Top,Left'
    $form.Controls.Add($logCaption) | Out-Null

    $buttonFlow = New-Object System.Windows.Forms.FlowLayoutPanel
    $buttonFlow.Location = New-Object System.Drawing.Point(16, 556)
    $buttonFlow.Size = New-Object System.Drawing.Size(728, 48)
    $buttonFlow.Anchor = 'Bottom,Left,Right'
    $buttonFlow.WrapContents = $true
    $form.Controls.Add($buttonFlow) | Out-Null

    $form.Tag = @{
        Checks           = $checks
        LogBox           = $logBox
        ButtonFlow       = $buttonFlow
        Subtitle         = $subtitle
        SubtitleDefault  = $subtitle.Text
        Buttons          = @{}
    }

    return $form
}

function Add-GuiLog {
    param([string]$Message)
    $form = $script:Form
    if (-not $form) { return }
    $box = $form.Tag.LogBox
    if ("$Message".Trim()) { $box.AppendText(("$Message`r`n")) }
    $box.SelectionStart = $box.TextLength
    $box.ScrollToCaret()
    [System.Windows.Forms.Application]::DoEvents()
}

function Update-GuiChecks {
    <#
        Repaints the checklist from $script:Checks, an array of ordered rows:
        @{ Name = '...'; Status = 'Pending|OK|Fail|Busy'; Detail = '...' }
    #>
    $form = $script:Form
    $list = $form.Tag.Checks
    $list.BeginUpdate()
    try {
        $list.Items.Clear()
        foreach ($row in $script:Checks) {
            $item = New-Object System.Windows.Forms.ListViewItem($row.Name)
            $item.SubItems.Add($row.Status) | Out-Null
            $item.SubItems.Add($row.Detail) | Out-Null

            switch ($row.Status) {
                'OK'     { $item.ForeColor = [System.Drawing.Color]::ForestGreen }
                'Fail'   { $item.ForeColor = [System.Drawing.Color]::Firebrick }
                'Busy'   { $item.ForeColor = [System.Drawing.Color]::DarkOrange }
                'Pending'{ $item.ForeColor = [System.Drawing.Color]::DimGray }
                default  { $item.ForeColor = [System.Drawing.Color]::DimGray }
            }
            $list.Items.Add($item) | Out-Null
        }
    }
    finally {
        $list.EndUpdate()
    }
}

function Set-GuiButtons {
    <#
        Rebuilds the button row for the given state. Each entry is
        @{ Key; Text; Primary; Action; Visible }
    #>
    param([Parameter(Mandatory = $true)][object[]]$Buttons)

    $flow = $script:Form.Tag.ButtonFlow
    $flow.SuspendLayout()
    try {
        $flow.Controls.Clear()
        foreach ($definition in $Buttons) {
            if (-not $definition.Visible) { continue }

            $button = New-Object System.Windows.Forms.Button
            $button.Text = $definition.Text
            $button.AutoSize = $true
            $button.Height = 30
            $button.Margin = New-Object System.Windows.Forms.Padding(0, 4, 8, 0)
            if ($definition.Primary) { $button.Font = New-Object System.Drawing.Font('Segoe UI', 9, [System.Drawing.FontStyle]::Bold) }
            if ($definition.Action) {
                $handler = $definition.Action
                $button.Add_Click($handler)
            }
            else {
                $button.Enabled = $false
            }
            $flow.Controls.Add($button) | Out-Null
        }
    }
    finally {
        $flow.ResumeLayout()
    }
}

function Show-Message {
    param(
        [string]$Text,
        [System.Windows.Forms.MessageBoxButtons]$Buttons = 'OK',
        [System.Windows.Forms.MessageBoxIcon]$Icon = 'Information'
    )
    return [System.Windows.Forms.MessageBox]::Show($script:Form, $Text, 'AOG Connector', $Buttons, $Icon)
}

function Invoke-Progress {
    <#
        Long operations run synchronously, so the window would freeze otherwise.
        This pumps the message queue while a status string is displayed.
    #>
    param(
        [string]$Message,
        [int]$Iterations = 1,
        [int]$DelayMs = 200
    )
    for ($i = 0; $i -lt $Iterations; $i++) {
        $script:Form.Tag.Subtitle.Text = $Message
        $script:Form.Tag.Checks.Refresh()
        [System.Windows.Forms.Application]::DoEvents()
        if ($Iterations -gt 1) { Start-Sleep -Milliseconds $DelayMs }
    }
    $script:Form.Tag.Subtitle.Text = $script:Form.Tag.SubtitleDefault
}

function Get-Checklist {
    <#
        Runs every dependency check and returns the ordered checklist rows plus a
        summary flag telling the GUI whether the bridge can be started.
    #>
    $rows = @()
    $allReady = $true

    $missingFiles = Get-MissingReleaseFiles
    if ($missingFiles.Count -eq 0) {
        $rows += @{ Name = 'Release files'; Status = 'OK'; Detail = 'companion\aog_bridge.py and companion\requirements.txt found' }
    }
    else {
        $rows += @{ Name = 'Release files'; Status = 'Fail'; Detail = "Missing: $($missingFiles -join ', '). Extract the release ZIP fully." }
        $allReady = $false
    }

    $python = Get-PythonInfo
    $script:Python = $python
    if ($python) {
        $rows += @{ Name = 'Python (64-bit)'; Status = 'OK'; Detail = "$($python.Version) 64-bit - $($python.Executable)" }
    }
    else {
        $rows += @{ Name = 'Python (64-bit)'; Status = 'Fail'; Detail = "No 64-bit Python $($script:MinPythonVersion)+ found. Install it below." }
        $allReady = $false
    }

    if (-not $python) {
        $rows += @{ Name = 'Virtual environment'; Status = 'Pending'; Detail = 'Waiting for Python' }
        $rows += @{ Name = 'Bridge dependencies (pywin32)'; Status = 'Pending'; Detail = 'Waiting for Python' }
        return [pscustomobject]@{ Rows = $rows; Ready = $false }
    }

    if (Test-Path -LiteralPath $script:VenvPython) {
        $rows += @{ Name = 'Virtual environment'; Status = 'OK'; Detail = '.venv already exists' }
    }
    else {
        $rows += @{ Name = 'Virtual environment'; Status = 'Pending'; Detail = 'Not created yet - use "Install Dependencies"' }
        $rows += @{ Name = 'Bridge dependencies (pywin32)'; Status = 'Pending'; Detail = 'Not installed yet' }
        $allReady = $false
        return [pscustomobject]@{ Rows = $rows; Ready = $false }
    }

    if (Test-BridgeDependencies) {
        $rows += @{ Name = 'Bridge dependencies (pywin32)'; Status = 'OK'; Detail = 'win32pipe, win32file, win32event import cleanly' }
    }
    else {
        $rows += @{ Name = 'Bridge dependencies (pywin32)'; Status = 'Fail'; Detail = 'pywin32 missing - use "Install Dependencies"' }
        $allReady = $false
    }

    return [pscustomobject]@{ Rows = $rows; Ready = $allReady }
}

function Update-Checklist {
    <#
        Re-runs the checks and rebuilds both the checklist and the button row for
        whatever state we end up in.
    #>
    $result = Get-Checklist
    $script:Checks = $result.Rows
    Update-GuiChecks

    if ($result.Ready) {
        Set-GuiButtons -Buttons @(
            @{ Text = 'Start Bridge'; Primary = $true; Action = $script:Actions.StartBridge; Visible = $true },
            @{ Text = 'Re-check'; Primary = $false; Action = $script:Actions.Recheck; Visible = $true },
            @{ Text = 'Install Dependencies'; Primary = $false; Action = $script:Actions.InstallDependencies; Visible = $true },
            @{ Text = 'Open Release Folder'; Primary = $false; Action = $script:Actions.OpenFolder; Visible = $true },
            @{ Text = 'Close'; Primary = $false; Action = $script:Actions.Close; Visible = $true }
        )
    }
    elseif ($script:Python) {
        Set-GuiButtons -Buttons @(
            @{ Text = 'Install Dependencies'; Primary = $true; Action = $script:Actions.InstallDependencies; Visible = $true },
            @{ Text = 'Re-check'; Primary = $false; Action = $script:Actions.Recheck; Visible = $true },
            @{ Text = 'Open Release Folder'; Primary = $false; Action = $script:Actions.OpenFolder; Visible = $true },
            @{ Text = 'Close'; Primary = $false; Action = $script:Actions.Close; Visible = $true }
        )
    }
    else {
        Set-GuiButtons -Buttons @(
            @{ Text = 'Download and Install Python'; Primary = $true; Action = $script:Actions.InstallPython; Visible = $true },
            @{ Text = 'Open python.org Download Page'; Primary = $false; Action = $script:Actions.OpenPythonSite; Visible = $true },
            @{ Text = 'Re-check'; Primary = $false; Action = $script:Actions.Recheck; Visible = $true },
            @{ Text = 'Open Release Folder'; Primary = $false; Action = $script:Actions.OpenFolder; Visible = $true },
            @{ Text = 'Close'; Primary = $false; Action = $script:Actions.Close; Visible = $true }
        )
    }

    return $result
}

function Invoke-Action {
    <#
        Runs one launcher action and reports any unexpected failure instead of
        letting it die silently behind the window. This is a function rather than
        a captured scriptblock because the button handlers run long after
        Register-Actions has returned.
    #>
    param(
        [Parameter(Mandatory = $true)][string]$Name,
        [Parameter(Mandatory = $true)][scriptblock]$Body
    )
    try {
        & $Body
    }
    catch {
        Add-GuiLog ("ERROR in {0}: {1}" -f $Name, $_.Exception.Message)
        $null = Show-Message -Text ("{0} failed:`r`n`r`n{1}" -f $Name, $_.Exception.Message) -Buttons 'OK' -Icon 'Error'
        $null = Update-Checklist
    }
}

function Register-Actions {
    return @{
        Recheck = {
            & Invoke-Action 'Re-check' { Add-GuiLog '--- Re-running dependency checks ---'; $null = Update-Checklist }
        }

        OpenPythonSite = {
            & Invoke-Action 'Open python.org' {
                Add-GuiLog "Opening $script:PythonWindowsUrl"
                Start-Process $script:PythonWindowsUrl
                Add-GuiLog 'Install Python 3.12 x64 (the launcher must stay open), then press Re-check.'
            }
        }

        OpenFolder = {
            & Invoke-Action 'Open Release Folder' {
                Add-GuiLog "Opening $script:Root"
                Start-Process explorer.exe -ArgumentList ('"' + $script:Root + '"')
            }
        }

        Close = {
            $script:Form.Close()
        }

        InstallPython = {
            & Invoke-Action 'Python installation' {
                Add-GuiLog '--- Downloading and installing Python ---'

                $url = Get-LatestPythonInstallerUrl
                if (-not $url) {
                    Add-GuiLog 'Could not reach the python.org download index.'
                    $answer = Show-Message -Text ("Could not query python.org for the latest installer.`r`n`r`nOpen the download page and install Python 3.12 x64 yourself?") -Buttons 'YesNo' -Icon 'Question'
                    if ($answer -eq [System.Windows.Forms.DialogResult]::Yes) { Start-Process $script:PythonWindowsUrl }
                    return
                }

                Add-GuiLog "Installer URL: $url"
                $progress = { param($message) Add-GuiLog $message; Invoke-Progress $message 1 }

                $installer = Save-PythonInstaller -Url $url -Progress $progress
                $exitCode = Install-PythonSilently -InstallerPath $installer -Progress $progress

                if ($exitCode -eq 0 -or $exitCode -eq 3010) {
                    if ($exitCode -eq 3010) { Add-GuiLog 'Installer asked for a reboot to finish. Restart Windows if Python is not found below.' }
                    Add-GuiLog 'Python installation finished. Re-checking...'
                }
                else {
                    Add-GuiLog "Python installer exited with code $exitCode."
                }

                $null = Update-Checklist
                if (-not $script:Python) {
                    $answer = Show-Message -Text ("Python still was not detected.`r`n`r`nIf you just installed it, restart Windows and run the launcher again. Open the python.org download page instead?") -Buttons 'YesNo' -Icon 'Warning'
                    if ($answer -eq [System.Windows.Forms.DialogResult]::Yes) { Start-Process $script:PythonWindowsUrl }
                }
            }
        }

        InstallDependencies = {
            & Invoke-Action 'Dependency installation' {
                if (-not $script:Python) {
                    $null = Update-Checklist
                    return
                }

                Add-GuiLog '--- Installing bridge dependencies into .venv ---'
                Add-GuiLog 'This does not change your system-wide Python packages.'

                if (-not (Test-Path -LiteralPath $script:VenvPython)) {
                    Invoke-Progress 'Creating virtual environment (.venv)...'
                    $venv = Invoke-VenvCreation -Python $script:Python
                    if ($venv.ExitCode -ne 0 -or -not (Test-Path -LiteralPath $script:VenvPython)) {
                        Add-GuiLog "Virtual environment creation failed: $($venv.Error)$($venv.Output)"
                        $null = Show-Message -Text "Could not create the .venv virtual environment.`r`n`r`nCheck that you can write to this folder and that Python is not busy." -Buttons 'OK' -Icon 'Error'
                        $null = Update-Checklist
                        return
                    }
                    Add-GuiLog 'Virtual environment created.'
                }

                Invoke-Progress 'Installing requirements from companion\requirements.txt...'
                $pip = Invoke-PipInstall -Python $script:Python
                foreach ($line in (($pip.Output + $pip.Error) -split "`r?`n")) {
                    if ($line.Trim()) { Add-GuiLog ("  pip: " + $line.Trim()) }
                }
                if ($pip.ExitCode -ne 0) {
                    Add-GuiLog 'pip install failed.'
                    $detail = (($pip.Error + $pip.Output) -split "`r?`n" | Where-Object { $_.Trim() } | Select-Object -Last 4) -join "`r`n"
                    $null = Show-Message -Text ("pip install failed. The exact reason is in the log.`r`n`r`n$detail`r`n`r`nCommon causes: no internet connection for the first-time pywin32 download, a proxy/firewall blocking pypi.org, or a read-only release folder.") -Buttons 'OK' -Icon 'Error'
                }

                $null = Update-Checklist
                if (Test-BridgeDependencies) {
                    Add-GuiLog 'Setup complete. The bridge can now be started.'
                }
            }
        }

        StartBridge = {
            & Invoke-Action 'Start bridge' {
                $result = Update-Checklist
                if (-not $result.Ready) {
                    $null = Show-Message -Text 'Dependencies are not satisfied yet. Fix the red items first.' -Buttons 'OK' -Icon 'Warning'
                    return
                }

                Add-GuiLog '--- Starting the bridge ---'
                $bridge = Start-Bridge
                Add-GuiLog ("Bridge started in a new console window (PID {0})." -f $bridge.Id)
                Add-GuiLog 'Keep that window open while playing; press q in it to stop the bridge.'
                Add-GuiLog 'Wait for "Waiting for FS25 to connect", then load your save in FS25.'
                $null = Show-Message -Text ("The bridge is running in its own console window (PID {0}).`r`n`r`nKeep that window open while you play and press 'q' there to stop it." -f $bridge.Id) -Buttons 'OK' -Icon 'Information'
            }
        }
    }
}

# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

function Test-RequiresStaRestart {
    <#
        WinForms needs a single-threaded apartment. The .cmd shim launches with
        -STA, but a user running the .ps1 straight from a console might not, so
        relaunch once in that case.
    #>
    if ([System.Threading.Thread]::CurrentThread.GetApartmentState() -eq 'STA') { return $false }
    if ($env:AOG_LAUNCHER_RELAUNCHED -eq '1') { return $false }

    $host = (Get-Process -Id $PID).Path
    if (-not $host) { return $false }

    $arguments = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-STA', '-File', ('"' + $PSCommandPath + '"'))
    if ($SetupOnly) { $arguments += '-SetupOnly' }
    if ($NonInteractive) { $arguments += '-NonInteractive' }

    $env:AOG_LAUNCHER_RELAUNCHED = '1'
    $process = Start-Process -FilePath $host -ArgumentList $arguments -WorkingDirectory $script:Root -PassThru
    $process.WaitForExit()
    return $true
}

function Invoke-Main {
    if (-not $NonInteractive -and -not $env:AOG_NONINTERACTIVE) {
        if (Test-RequiresStaRestart) { return 0 }

        $script:Form = Initialize-Gui
        $script:Actions = Register-Actions

        Add-GuiLog "AOG Connector launcher - $script:Root"
        Add-GuiLog ''

        $script:Form.Add_FormClosing({
            if (Test-Path -LiteralPath $script:WorkDir) {
                Remove-Item -LiteralPath $script:WorkDir -Recurse -Force -ErrorAction SilentlyContinue
            }
        })

        $null = Update-Checklist

        if (-not $script:Python) {
            Add-GuiLog ''
            Add-GuiLog 'Python was not found. Use "Download and Install Python" for the automatic route,'
            Add-GuiLog 'or "Open python.org Download Page" to install it yourself, then press Re-check.'
        }

        [void]$script:Form.ShowDialog()
        return 0
    }

    return Invoke-NonInteractive -SetupOnly ([bool]$SetupOnly)
}

$exitCode = 1
try {
    $exitCode = Invoke-Main
}
catch {
    $message = "AOG Connector launcher failed:`r`n`r`n$($_.Exception.Message)"
    if ($NonInteractive -or $env:AOG_NONINTERACTIVE) {
        Write-Error $message
    }
    else {
        try {
            Add-Type -AssemblyName System.Windows.Forms
            $null = [System.Windows.Forms.MessageBox]::Show($message, 'AOG Connector', 'OK', 'Error')
        }
        catch {
            Write-Error $message
        }
    }
    $exitCode = 1
}
finally {
    if (Test-Path -LiteralPath $script:WorkDir) {
        Remove-Item -LiteralPath $script:WorkDir -Recurse -Force -ErrorAction SilentlyContinue
    }
}

exit $exitCode
