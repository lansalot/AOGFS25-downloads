@echo off
setlocal
call "%~dp0AOGConnectorConfig.cmd" %*
exit /b %errorlevel%
