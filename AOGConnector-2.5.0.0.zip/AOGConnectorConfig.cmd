@echo off
setlocal
cd /d "%~dp0"
rem Launch the configuration script without changing the machine execution policy.
echo "Launching AOG Connector Configuration - just a moment..."
powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0AOGConnectorConfig.ps1" %*
set "launcher_exit=%errorlevel%"
if not defined AOG_NONINTERACTIVE if %launcher_exit% neq 0 (
    echo.
    echo Launcher exited with code %launcher_exit%. See the window above and INSTALL.txt.
    pause
)
exit /b %launcher_exit%
