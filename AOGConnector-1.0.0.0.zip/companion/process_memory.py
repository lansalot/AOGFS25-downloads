"""Windows process-memory transport used by the AOGConnector companion tools."""

from __future__ import annotations

import ctypes
from ctypes import wintypes
import os
import sys

if sys.platform != "win32":
    raise RuntimeError("AOGConnector process memory transport only supports Windows.")

DEFAULT_PROCESS_NAME = "FarmingSimulator2025Game.exe"
MARKER_START = b"AOG_FS25_INPUT_BUFFER_V1_START"
MARKER_END = b"AOG_FS25_INPUT_BUFFER_V1_END"
PROCESS_VM_OPERATION = 0x0008
PROCESS_VM_READ = 0x0010
PROCESS_VM_WRITE = 0x0020
PROCESS_QUERY_INFORMATION = 0x0400
MEM_COMMIT = 0x1000
PAGE_NOACCESS = 0x01
PAGE_GUARD = 0x100
SCAN_CHUNK_SIZE = 1024 * 1024

kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
psapi = ctypes.WinDLL("psapi", use_last_error=True)


class MEMORY_BASIC_INFORMATION(ctypes.Structure):
    _fields_ = [
        ("BaseAddress", ctypes.c_void_p), ("AllocationBase", ctypes.c_void_p),
        ("AllocationProtect", wintypes.DWORD), ("PartitionId", wintypes.WORD),
        ("RegionSize", ctypes.c_size_t), ("State", wintypes.DWORD),
        ("Protect", wintypes.DWORD), ("Type", wintypes.DWORD),
    ]


kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
kernel32.OpenProcess.restype = wintypes.HANDLE
kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
kernel32.CloseHandle.restype = wintypes.BOOL
kernel32.QueryFullProcessImageNameW.argtypes = [wintypes.HANDLE, wintypes.DWORD,
    wintypes.LPWSTR, ctypes.POINTER(wintypes.DWORD)]
kernel32.QueryFullProcessImageNameW.restype = wintypes.BOOL
kernel32.VirtualQueryEx.argtypes = [wintypes.HANDLE, ctypes.c_void_p,
    ctypes.POINTER(MEMORY_BASIC_INFORMATION), ctypes.c_size_t]
kernel32.VirtualQueryEx.restype = ctypes.c_size_t
kernel32.ReadProcessMemory.argtypes = [wintypes.HANDLE, ctypes.c_void_p, ctypes.c_void_p,
    ctypes.c_size_t, ctypes.POINTER(ctypes.c_size_t)]
kernel32.ReadProcessMemory.restype = wintypes.BOOL
kernel32.WriteProcessMemory.argtypes = [wintypes.HANDLE, ctypes.c_void_p, ctypes.c_void_p,
    ctypes.c_size_t, ctypes.POINTER(ctypes.c_size_t)]
kernel32.WriteProcessMemory.restype = wintypes.BOOL
psapi.EnumProcesses.argtypes = [ctypes.POINTER(wintypes.DWORD), wintypes.DWORD,
    ctypes.POINTER(wintypes.DWORD)]
psapi.EnumProcesses.restype = wintypes.BOOL


def _windows_error(message: str) -> OSError:
    return ctypes.WinError(ctypes.get_last_error(), message)


def find_process_id(process_name: str = DEFAULT_PROCESS_NAME) -> int:
    capacity = 4096
    while True:
        process_ids = (wintypes.DWORD * capacity)()
        bytes_returned = wintypes.DWORD()
        if not psapi.EnumProcesses(process_ids, ctypes.sizeof(process_ids),
                                   ctypes.byref(bytes_returned)):
            raise _windows_error("Could not enumerate processes")
        count = bytes_returned.value // ctypes.sizeof(wintypes.DWORD)
        if count < capacity:
            break
        capacity *= 2

    for process_id in process_ids[:count]:
        handle = kernel32.OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ,
                                      False, process_id)
        if not handle:
            continue
        try:
            path = ctypes.create_unicode_buffer(32768)
            path_length = wintypes.DWORD(len(path))
            if kernel32.QueryFullProcessImageNameW(handle, 0, path,
                                                   ctypes.byref(path_length)):
                if os.path.basename(path.value).casefold() == process_name.casefold():
                    return process_id
        finally:
            kernel32.CloseHandle(handle)
    raise RuntimeError(f"Process '{process_name}' was not found. Start FS25 first.")


def read_memory(handle: int, address: int, size: int) -> bytes | None:
    buffer = ctypes.create_string_buffer(size)
    bytes_read = ctypes.c_size_t()
    if not kernel32.ReadProcessMemory(handle, ctypes.c_void_p(address), buffer, size,
                                      ctypes.byref(bytes_read)):
        return None
    return buffer.raw[:bytes_read.value]


def find_buffer(handle: int, marker_start: bytes = MARKER_START,
                marker_end: bytes = MARKER_END) -> tuple[int, int]:
    address = 0
    info = MEMORY_BASIC_INFORMATION()
    overlap = len(marker_start) - 1
    while kernel32.VirtualQueryEx(handle, ctypes.c_void_p(address), ctypes.byref(info),
                                  ctypes.sizeof(info)):
        base = int(info.BaseAddress or 0)
        region_size = int(info.RegionSize)
        if (info.State == MEM_COMMIT and not (info.Protect & PAGE_GUARD)
                and not (info.Protect & PAGE_NOACCESS)):
            offset, tail = 0, b""
            while offset < region_size:
                chunk_size = min(SCAN_CHUNK_SIZE, region_size - offset)
                chunk = read_memory(handle, base + offset, chunk_size)
                if chunk is None:
                    break
                searchable = tail + chunk
                search_from = 0
                while True:
                    found = searchable.find(marker_start, search_from)
                    if found < 0:
                        break
                    candidate = base + offset - len(tail) + found
                    length_raw = read_memory(handle, candidate + len(marker_start), 1)
                    if length_raw:
                        payload_size = length_raw[0]
                        end_address = candidate + len(marker_start) + 1 + payload_size
                        if read_memory(handle, end_address, len(marker_end)) == marker_end:
                            return candidate + len(marker_start) + 1, payload_size
                    search_from = found + 1
                tail = searchable[-overlap:]
                offset += chunk_size
        next_address = base + max(region_size, 1)
        if next_address <= address:
            break
        address = next_address
    raise RuntimeError("AOG input buffer was not found. Is the enabled mod loaded?")


class ProcessMemoryBuffer:
    def __init__(self, process_name: str = DEFAULT_PROCESS_NAME):
        self.process_id = find_process_id(process_name)
        access = PROCESS_QUERY_INFORMATION | PROCESS_VM_OPERATION | PROCESS_VM_READ | PROCESS_VM_WRITE
        self.handle = kernel32.OpenProcess(access, False, self.process_id)
        if not self.handle:
            raise _windows_error(f"Could not open process {self.process_id}")
        try:
            self.address, self.size = find_buffer(self.handle)
        except Exception:
            self.close()
            raise

    def close(self) -> None:
        if self.handle:
            kernel32.CloseHandle(self.handle)
            self.handle = None

    def __enter__(self) -> "ProcessMemoryBuffer":
        return self

    def __exit__(self, _exc_type, _exc_value, _traceback) -> None:
        self.close()

    def _write(self, offset: int, data: bytes) -> None:
        if offset < 0 or offset + len(data) > self.size:
            raise ValueError("Write exceeds process-memory buffer capacity.")
        source = ctypes.create_string_buffer(data, len(data))
        bytes_written = ctypes.c_size_t()
        if not kernel32.WriteProcessMemory(self.handle, ctypes.c_void_p(self.address + offset),
                source, len(data), ctypes.byref(bytes_written)):
            raise _windows_error("Could not write FS25 process memory")
        if bytes_written.value != len(data):
            raise RuntimeError(f"Only wrote {bytes_written.value} of {len(data)} bytes.")

    def write(self, text: str) -> None:
        encoded = text.encode("ascii")
        if len(encoded) > self.size:
            raise ValueError(f"Payload is {len(encoded)} bytes; capacity is {self.size}.")
        self._write(0, encoded.ljust(self.size, b" "))

    def write_committed(self, text: str) -> None:
        """Invalidate, write the frame body, then commit its first byte last."""
        encoded = text.encode("ascii")
        if not encoded:
            raise ValueError("Committed payload cannot be empty.")
        if len(encoded) > self.size:
            raise ValueError(f"Payload is {len(encoded)} bytes; capacity is {self.size}.")
        padded = encoded.ljust(self.size, b" ")
        self._write(0, b"!")
        self._write(1, padded[1:])
        self._write(0, padded[:1])


def command_checksum(body: str) -> int:
    return sum(body.encode("ascii")) % 65536


def build_steer_command(sequence: int, setpoint_deg: float, guidance_status: int) -> str:
    sequence %= 1_000_000_000
    setpoint_centideg = max(-5000, min(5000, round(setpoint_deg * 100)))
    guidance_status = max(0, min(255, int(guidance_status)))
    body = f"AOG1|{sequence}|{setpoint_centideg}|{guidance_status}"
    return f"{body}|{command_checksum(body)}"