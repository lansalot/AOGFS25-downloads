@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
    echo Run Setup.cmd first, then start the bridge again.
    if not defined AOG_NONINTERACTIVE pause
    exit /b 1
)
".venv\Scripts\python.exe" -u "companion\aog_bridge.py"
set "bridge_exit=%errorlevel%"
if not defined AOG_NONINTERACTIVE pause
exit /b %bridge_exit%