@echo off
setlocal
cd /d "%~dp0"
py -3.12 -c "import struct; assert struct.calcsize('P') == 8, '64-bit Python is required'"
if errorlevel 1 (
    echo Install Python 3.12 64-bit with the Python launcher, then run Setup again.
    goto failed
)
py -3.12 -m venv ".venv"
if errorlevel 1 goto failed
".venv\Scripts\python.exe" -m pip install --disable-pip-version-check -r "companion\requirements.txt"
if errorlevel 1 goto failed
".venv\Scripts\python.exe" -c "import win32pipe, win32file, win32event, pywintypes"
if errorlevel 1 goto failed
echo Setup complete. Run Start-Bridge.cmd each time you play.
if not defined AOG_NONINTERACTIVE pause
exit /b 0
:failed
echo Setup failed. Check the error above and the installation guide.
if not defined AOG_NONINTERACTIVE pause
exit /b 1